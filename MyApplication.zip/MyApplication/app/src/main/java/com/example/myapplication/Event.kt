package com.example.myapplication

data class Event(
    val title: String,
    val message: String,
    val location: String,
    val time: Long
)
