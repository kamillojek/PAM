package com.example.myapplication

object EventStore {
    val events = mutableListOf<Event>()
}