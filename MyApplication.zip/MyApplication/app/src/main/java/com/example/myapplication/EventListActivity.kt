package com.example.myapplication

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat

class EventListActivity : AppCompatActivity() {
    @SuppressLint("SimpleDateFormat")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_list)

        val listView = findViewById<ListView>(R.id.eventListView)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, EventStore.events.map {
            "${it.title} - ${SimpleDateFormat("MM/dd/yyyy hh:mm:ss").format(it.time)}"
        })
        listView.adapter = adapter
    }
}

